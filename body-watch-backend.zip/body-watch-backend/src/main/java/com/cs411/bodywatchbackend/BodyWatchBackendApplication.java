package com.cs411.bodywatchbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BodyWatchBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(BodyWatchBackendApplication.class, args);
	}

}
